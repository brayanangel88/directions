import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display-components',
  templateUrl: './display-components.component.html',
  styleUrls: ['./display-components.component.scss']
})
export class DisplayComponentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
